# Atlassian Samples

[![Start with AutoKitteh](https://autokitteh.com/assets/autokitteh-badge.svg)](https://app.autokitteh.cloud/template?template-name=samples/atlassian)

These [AutoKitteh](https://github.com/autokitteh/autokitteh) projects
demonstrate 2-way integration with Atlassian services and APIs.

- Confluence
- [Jira](./jira/)
